from models import PullRequest, ReviewResponse, ReviewComment

def analyze_code_quality(content: str) -> list:
    lines = content.splitlines()
    comments = []
    for i, line in enumerate(lines, start=1):
        if "print(" in line:
            comments.append((i, "Avoid using print statements in production code."))
        elif "eval(" in line:
            comments.append((i, "Use of eval is dangerous. Avoid if possible."))
        elif len(line.strip()) == 0:
            continue
        elif len(line.strip()) < 5:
            comments.append((i, "Line too short — consider adding meaningful content or removing it."))
    return comments

def analyze_pull_request(pr: PullRequest) -> ReviewResponse:
    all_comments = []
    for file in pr.changed_files:
        file_comments = analyze_code_quality(file.content)
        for line, comment in file_comments:
            all_comments.append(ReviewComment(
                filename=file.filename,
                line=line,
                comment=comment
            ))

    approved = len(all_comments) == 0
    summary = "PR approved with no issues." if approved else f"PR requires changes. Found {len(all_comments)} issue(s)."
    return ReviewResponse(approved=approved, summary=summary, comments=all_comments)

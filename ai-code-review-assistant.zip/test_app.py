from fastapi.testclient import TestClient
from app import app

client = TestClient(app)

def test_analyze():
    response = client.post("/analyze", json={
        "pr_id": "123",
        "title": "Add logging",
        "description": "Added print statement for debugging",
        "changed_files": [
            {"filename": "main.py", "content": "print('Hello')\nprint('Debug')"}
        ]
    })
    assert response.status_code == 200
    data = response.json()
    assert not data["approved"]
    assert "print" in data["comments"][0]["comment"]

from fastapi import FastAPI, HTTPException
from models import PullRequest, ReviewResponse
from review_engine import analyze_pull_request

app = FastAPI(title="AI-Powered Code Review Assistant")

@app.post("/analyze", response_model=ReviewResponse)
def analyze(pr: PullRequest):
    try:
        result = analyze_pull_request(pr)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# AI-Powered Code Review Assistant

An automated code review assistant that analyzes pull requests for basic code issues (e.g., unsafe code, debugging artifacts) and generates inline review comments. Built using FastAPI.

## Features
- Analyze code for common bad practices
- Add comments with line-level suggestions
- Approve/reject pull requests with a summary
- Simple REST API for integration

## Tech Stack
- FastAPI
- Pydantic
- Python 3.9+

## Setup
```bash
# Clone the repo
git clone https://github.com/your-username/ai-code-review-assistant.git
cd ai-code-review-assistant

# Install dependencies
pip install -r requirements.txt

# Run the server
uvicorn app:app --reload
```

## Example API Call
**POST** `/analyze`

### Request
```json
{
  "pr_id": "123",
  "title": "Fix eval usage",
  "description": "This PR removes dangerous eval() call",
  "changed_files": [
    {
      "filename": "secure.py",
      "content": "eval(input())"
    }
  ]
}
```

### Response
```json
{
  "approved": false,
  "summary": "PR requires changes. Found 1 issue(s).",
  "comments": [
    {
      "filename": "secure.py",
      "line": 1,
      "comment": "Use of eval is dangerous. Avoid if possible."
    }
  ]
}
```

## TODO
- [ ] GitHub webhook integration
- [ ] Add LLM-based analysis
- [ ] Multi-language support (Python, JS, etc)
- [ ] Web UI for review dashboard

## How It Works (Theory to Code)

The assistant mimics how a human reviewer checks a pull request:

1. **Receives PR Data**: Using `PullRequest` Pydantic model.
2. **Parses Code Files**: Line-by-line inspection in `analyze_code_quality`.
3. **Detects Issues**: Simple rules like detecting `print()` or `eval()`.
4. **Adds Comments**: Attaches comments with filename and line number.
5. **Responds with Verdict**: Whether to approve or request changes, with a summary.

Future upgrades will use LLMs and deeper static analysis to better simulate a real code review.

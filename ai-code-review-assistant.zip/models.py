from pydantic import BaseModel
from typing import List

class FileChange(BaseModel):
    filename: str
    content: str

class PullRequest(BaseModel):
    pr_id: str
    title: str
    description: str
    changed_files: List[FileChange]

class ReviewComment(BaseModel):
    filename: str
    line: int
    comment: str

class ReviewResponse(BaseModel):
    approved: bool
    summary: str
    comments: List[ReviewComment]
